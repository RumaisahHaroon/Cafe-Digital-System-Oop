#include "admin.h"
#include <iostream>
#include<cstring>
#include <fstream>
using namespace std;

// Constructor definition
admin::admin(): Stock(),notifi()
{
    
}
void admin::displaya()
{
cout<<"                                   ****************************************"<<endl;
cout<<"                                   *                WELCOME               *"<<endl;
cout<<"                                   *                                      *"<<endl;
cout<<"                                   *                 ADMIN                *"<<endl;
cout<<"                                   ****************************************"<<endl;

}

void admin::logina()
{
//////login work
    char storedUsername[10]="ADMIN";
    char storedPassword[10]="1234";

    char enteredUsername[50];
    char enteredPassword[50];
    int login=0;
 do{
    cout << "Enter username: ";
    cin >> enteredUsername;

    cout << "Enter password: ";
    cin >> enteredPassword;

        if ((strcmp(enteredUsername, storedUsername) == 0 )&&( strcmp(enteredPassword, storedPassword) == 0)) {
           cout << "Login successful!" << endl;
           login=1;
        }
        else
        {
             cout << "Login failed. Incorrect username or password." <<endl;// User not found or password doesn't match
             login=0;
        }
  
  }while(login==0) ;
         
}
////////////after login
void admin::choicea()
{
int c;
do{
cout<<"*******************************************************************************************************"<<endl;
  cout<<"Select the desired option\n1.Handle stock items\n2.View credentials(Add/Remove)\n3.Notifications\n4.Scedeuled orders\n5.View Complaints\n6.Exit\n";
 cin>>c;
 switch(c)
 {
  case 1:
  {
   cout<<"***********************************************************************************************************"<<endl;
   Stock::displays();
   Stock::choices();
   break;
  }
  case 2 :
  {
   cout<<"*******************************************************************************************************"<<endl;
   credentials();
   break;
  }
  case 3:
  {
   cout<<"*******************************************************************************************************"<<endl;
   notification();
   break;
  }
  case 4 :
  {
   cout<<"*******************************************************************************************************"<<endl;
   scorder();
   break;
  }
  case 5 :
  {
  cout<<"*******************************************************************************************************"<<endl;
   viewcomplains();
   break;
  }  
  case 6 :
  {
  cout<<"Exiting"<<endl;
   
   break;
  }
  default:
  {
   cout<<"INVALID INPUT"<<endl;
  }

 }
 }while(c != 6);   
 
 }
////////////implementation pof member functions
void admin::credentials() 
{
        char head[30], emp[5][10];
        int Pass[5];
	int i=0;
	
	fstream fs("emp.txt",ios::in);
	
	if (!fs)//check if file is not available to read
	{
		cout<<"\nFile not found";
		cout<<"\nCheck file name";
	}
	else//file is available for reading now loading data in arrays appropriately
	{
		cout<<"\nFile Found Congrats";
		fs.getline(head,30,'\n');//reading first line of file
		//reading remianing records of file in arrays 
		while(fs.getline(emp[i],10,' '),fs>>Pass[i])
		{
			fs.ignore();
			i++;
		}
					
	}
	
	fs.close();
	//now printing data from arrays on screen
		
	cout<<"\nData read from file in arrays ::: \n";
	cout<<"\n"<<head<<endl;
	for(int k=0;k<i;k++)
	{
		cout<<emp[k]<<"    |"<<Pass[k]<<endl;
	}
    int choice;
    do {
    	//////////menu display
        cout << "\n\nCredentials Menu\n1.Add employee\n2.Remove employee\n3.Exit\n";
        cin >> choice;

        switch (choice) {
            case 1: {
                cin.ignore();  // Clear the input buffer
                char newempname[50];
                char newemppassword[50];

                cout << "Enter the employee name: ";
                cin.getline(newempname, 50);

                cout << "Enter the employee password: ";
                cin.getline(newemppassword, 50);

                ofstream addemp("emp.txt", ios::app);///////opening file for writing
                addemp << newempname << " " << newemppassword << endl;
                addemp.close();
                cout << "Employee added successfully." << endl;
                break;
            }
            case 2: {
                cin.ignore();  // Clear the input buffer
                int noemp;
                char empremove[50];
                cout << "Enter the numbers of employees: ";
                cin >> noemp;
                cout << "Enter the name of the employee to remove: ";
                cin.ignore(); // Consume newline character
                cin.getline(empremove, 50);

                // Open the original file for reading
                ifstream readEmployeesFile("emp.txt");
                if (!readEmployeesFile) {
                    cout << "Error: Failed to open emp.txt for reading." << endl;
                    break;
                }

                // Open a temporary file for writing
                ofstream tempFile("temp.txt");
                if (!tempFile) {
                    cout << "Error: Failed to open temp.txt for writing." << endl;
                    break;
                }

                char emp[5][10];
                int Pass[5];
                int i = 0;

                while (readEmployeesFile.getline(emp[i], 10, ' '), readEmployeesFile >> Pass[i]) {
                    readEmployeesFile.ignore();
                    if (strcmp(emp[i], empremove) != 0) {
                        tempFile << emp[i] << " " << Pass[i] << endl;
                    }
                    i++;
                }

                readEmployeesFile.close();
                tempFile.close();
                
                remove("emp.txt");//////removes org file
                rename("temp.txt", "emp.txt");///////renaming new file

                cout << "Employee removed successfully." << endl;
                break;
            }
            case 3: {
                cout << "Exiting" << endl;
                break;
            }
            default: {
                cout << "INVALID INPUT" << endl;
            }
        }
    } while (choice != 3);
}

void admin::notification()
{
    notifi::addnotifi();
}

void admin::scorder()
{
int choice;
cout<<"*******************************************************************************************************"<<endl;
 cout<<"\n\nMENU\n1.View order\n2.Write responses\n";
 cin>>choice;
 switch (choice)
 {
 case 1:
 {
 ifstream order("order.txt");

    if (!order.is_open()) {
        cout << "Error opening file" << endl;
        
    }

    cout << "Online Orders:" << endl;
    char neworder[100];
    int orderNumber = 1;

    while (order.getline(neworder, 100)) {
        cout << "Order " << orderNumber << ": " << neworder << endl;
        orderNumber++;
    }

    order.close();
    break;
  }
  case 2:
  {
    int ord;
    char response[100];
   cout<<"Enter the number of order::";
   cin>>ord;
   cout<<"Enter the response::";
   cin.ignore();
   cin.getline(response,100);
   fstream n("order.txt",ios::in|ios::app);
   n.ignore();
   
   n<<ord<<" "<<response<<"\n";
   n.close();
   break;
  }
}

}

void admin::viewcomplains()
{
cout<<"*******************************************************************************************************"<<endl;
   ifstream comp("complain.txt");///////open file for reading
    if (comp.is_open()) {
        cout << "Complains:\n";
        
        char complain[100];
        while (comp.getline(complain, 100)) {
            cout << complain <<endl;
        }
        comp.close();
    } else {
        cout << "Error opening notifications file." << endl;
    }
}
admin::~admin(){}

