#ifndef STOCK_H
#define STOCK_H



class Stock {
private:
    char head[30];
    char item[50][50];
    double Price[50];
    int No_Items[50];
    int itemCount;

public:
    Stock();
    virtual ~Stock();
    void displays();
    void choices();
    void addstock();
    void removestock();
    double updatestock(int,int);

    
};

#endif // STOCK_H
