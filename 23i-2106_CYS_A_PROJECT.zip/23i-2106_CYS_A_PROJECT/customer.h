#ifndef CUSTOMER_H
#define CUSTOMER_H
#include "stock.h"
#include "notifi.h"
class customer
{
private:
	notifi view;
	Stock menu;
public:
	customer();
	//////////member functions
	void displayc();
    	void choicec();
    	void orderfood();
    	void givecomplain();
    	void searchitems();
	void schorder();
	void viewnoti();
	void game();
	~customer();
};
#endif
