#ifndef EMP_H
#define EMP_H
#include "stock.h"
#include "notifi.h"
class emp:public Stock,public notifi
{
private:
	//char enteredUsername[50];
        //char enteredPassword[50];
public:
	emp(); // Constructor declaration
	//////////member functions
    	void displaye();
    	void logine();
    	void choicee();
    	void order(); 
    	void notifi();
    	void stocksearch();
    	~emp();
   
};
#endif
