#include "emp.h"
#include <iostream>
#include<cstring>
#include <fstream>
using namespace std;


emp::emp():Stock(){    //callinf constructor of inherited class
}
void emp::displaye()
{
cout<<"                                   ****************************************"<<endl;
cout<<"                                   *                WELCOME               *"<<endl;
cout<<"                                   *                                      *"<<endl;
cout<<"                                   *                EMPLOYEE              *"<<endl;
cout<<"                                   ****************************************"<<endl;
}
void emp::logine()
{

    int login=0;
    do{
        char head[30], emp[5][10];///////for reading from file and storing
        int Pass[5];

        int i = 0;

        char enteredUsername[50];
        char enteredPassword[50];

        cout << "Enter username: ";
        cin >> enteredUsername;

        cout << "Enter password: ";
        cin >> enteredPassword;

        fstream fs("emp.txt", ios::in);

        if (!fs) {
            cout << "\nFile not found\n";
            cout << "\nCheck file name\n";
        } else {
            cout << "\nFile Found Congrats\n";
            fs.getline(head, 30, '\n');
            while (fs.getline(emp[i], 10, ' '), fs >> Pass[i]) {
                fs.ignore();
                i++;
            }
        }

        fs.close();
        
        //ifstream rec("emprecord.txt",ios::app);
        //rec<<enteredUsername<<" "<<enteredPassword<<" "<<endl;
        //rec.close();
   
   
        login = 0;  // Reset login status

        for (int j = 0; j < i; j++) {
            if ((strcmp(emp[j], enteredUsername) == 0) && (Pass[j] == atoi(enteredPassword))) {
                cout << "\n\nLOGIN SUCCESSFUL\n\n";
                login = 1;
                break;  // Exit the loop if a match is found
            }
        }

        if (login == 0) {
            cout << "WRONG USERNAME OR PASSWORD\n\n";
        }

    }while (login == 0);
}

void emp::choicee()
{
	int choice;
	do{
  		cout<<"Select the desired option\n1.Take order\n2.View Notifications\n3.Search stock\n4.Exit\n";
 		cin>>choice;
 
 		switch(choice)
 		{
  			case 1:
  			{
   				order();
   				break;
  			}
  			case 2:
  			{
   				notifi();
   				break;
  			}
  			case 3:
  			{
   
   				stocksearch();
   				break;
  			}
  			case 4:
  			{
   				cout<<"EXITING"<<endl; 
  			}
  			default:
  			{
   				cout<<"INVALID INPUT"<<endl;
  			}

 		}
 		
 	}while(choice!=4);
}

void emp::order()
{
     Stock::displays();
/////////////////order scheduled food
    char choiceitem[50],NAME[50],numb[50];
    int choice, orderquantity, ordercount,id;
    
  //////////////checks identity  
     cout<<"Is the customer\n1.Staff memeber\n2. Student\n";
     cin>>id;
     
     if (id==1)
     {
           cout<<"Enter name of the staff member:";
           cin.ignore();
           cin.getline(NAME,50);
           cout<<"Enter id number::";
           cin.ignore();
           cin.getline(numb,50);
     }
     else
     {
           cout<<"Enter name of the student:";
           cin.ignore();
           cin.getline(NAME,50);
           cout<<"Enter roll number::";
           cin.ignore();
           cin.getline(numb,50);
     }
    //////////taking order
    cout<<"Enter the item you want to order";
    cin.ignore();
    cin.getline(choiceitem,50);
    cout << "Enter the number of item you want to order: ";
    cin >> choice;

if (choice >= 1 && choice <= 10)
    {
        cout << "Enter the quantity: ";
        cin >> orderquantity;
	int total_price= Stock::updatestock(orderquantity,choice);
        // Write order details to the file
        ofstream order("order.txt", ios::app);
              
        //order << "Item: " << choiceitem << "\nQuantity: " << orderquantity << "\nTotal Price: " << total_price<<"\n\n";
        
        if (id==1)
         {
          order<<"****STAFF****"<<endl;
          order<<"NAME: "<<NAME<<"      ID NUMBER: "<<numb<<endl;
          order << "Item: " << choiceitem << "\nQuantity: " << orderquantity << "\nTotal Price: " << total_price << "\n\n";
       
         }
         else
         {
          order<<"****STUDENT****"<<endl;
          order<<"NAME: "<<NAME<<"      ROLL NUMBER: "<<numb<<endl;
          order << "Item: " << choiceitem << "\nQuantity: " << orderquantity << "\nTotal Price: " << total_price << "\n\n";
          order.close();
        }
        
        cout << "Order placed successfully." << endl;
     /////////////////slip generating  
        cout << "\n------ Digital Slip ------\n";
        cout << "Item: " << choiceitem << "\n";
        cout << "Quantity: " << orderquantity << "\n";
        cout << "Total: $" << total_price << "\n";
        cout << "--------------------------\n";
        
        //ordercount++;////////////////counts order of ind emp
        
        
    }
    else
    {
        cout << "Invalid choice." << endl;
    }
}
void emp::notifi()
{
   
   notifi::viewnoti();////from composed classS
   
}

void emp::stocksearch()
{
   char head[30], item[10][50];
	double Price[10];
	int No_Items[10];
	int i=0;
	
	fstream fs("stock.txt",ios::in);
               fs.getline(head,30,'\n');
		while(fs.getline(item[i],50,' '),fs>>Price[i]>>No_Items[i])
		{
			fs.ignore();
			i++;
		}
	fs.close();
	
	
  char tobefound[50];
   int flag=0;
    // Clear the input buffer
    cout << "Enter the item name to search: ";
     cin.ignore(); 
    cin.getline(tobefound,50);
      for ( int j = 0; j < i; j++)
       {
          if (strcmp(item[j],tobefound) == 0) 
           {          
            flag=1;
            break;
           }
       }
      
      if (flag==1)
      {
       cout<<"ITEM FOUND"<<endl;
      }
      else
      {
       cout<<"ITEM NOT FOUND"<<endl;
      }
}

emp::~emp(){}
