#ifndef NOTIFI_H
#define NOTIFI_H

class notifi
{
	private:
	
	public:
		notifi();
		void viewnoti();
		void addnotifi();
		~notifi();
};
#endif
