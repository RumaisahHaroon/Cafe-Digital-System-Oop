#include <iostream>
#include <string.h>
#include<fstream>
#include <iomanip>
#include<cstring>
using namespace std;
#include "stock.h"
#include "admin.h"
#include "customer.h"
#include "emp.h"

//class admin;
int main() 
{
    string username, password;
    char id;
    cout << "                                   ****************************************" << endl;
    cout << "                                   *                                      *" << endl;
    cout << "                                   *           WELCOME TO CDS             *" << endl;
    cout << "                                   *                                      *" << endl;
    cout << "                                   ****************************************" << endl;
    cout << "SELECT WHO YOU ARE:\n1.ADMIN\n2.EMPLOYEE\n3.CUSTOMER\n";
    cin >> id;
    

    switch (id) 
    {
        case '1': 
        {     
            admin a1;
            a1.displaya();
            a1.logina();
            a1.choicea();
            break;
        }
        case '2': 
        {	
        	emp e1;
        	e1.displaye();        	
        	e1.logine();
        	e1.choicee();
            break;
        }
        case '3': 
        {
           customer c1;
           c1.displayc();
           c1.choicec();
        }
        default:
            cout << "Invalid choice." << endl;
            break;
    }

    return 0;
}
