#include "customer.h"
#include <iostream>
#include<cstring>
#include <fstream>
using namespace std;
customer::customer()
{}

void customer::displayc()
{
	cout<<"                                   ****************************************"<<endl;
	cout<<"                                   *                WELCOME               *"<<endl;
	cout<<"                                   *                                      *"<<endl;
	cout<<"                                   *               CUSTOMER               *"<<endl;
	cout<<"                                   ****************************************"<<endl;
}
void customer::choicec()
{
	int choice;
 do {
        cout << "Welcome to CDS Online Cafe:\n1. Order Food\n2. Give Complaint\n3. Search Items\n4. Give and Schedule  Order\n5. View Notifications\n6. Exit and play a game\nEnter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
            {
                orderfood();
                break;
                }

            case 2:
            {
               givecomplain();
                break;
                }

            case 3:
            {
                searchitems();
                break;
                }

            case 4:
            {
                schorder();
                break;
                }

            case 5:
            {
                viewnoti();
                break;
             }
            case 6:{
            	
            	game();
                cout << "Exiting the program.\n";
                
                break;
              }
            default:
            {
                cout << "Invalid choice. Please try again.\n";
            }
        }
    } while (choice != 6);
}

void customer::orderfood()
{
    menu.displays();
    // Order food
    char choiceitem[50];
    int choice, orderquantity, ordercount;
    cout<<"Enter the item you want to order";
    cin.ignore();
    cin.getline(choiceitem,50);
    
    cout << "Enter the number of item you want to order: ";
    cin >> choice;

    

    if (choice >= 1 && choice <= 10)
    {
        cout << "Enter the quantity: ";
        cin >> orderquantity;

        // Calculate the price
       int total_price= menu.updatestock(orderquantity,choice);
       
        // Write order details to the file
        ofstream order("order.txt", ios::app);
        order << "Item: " << choiceitem << "\nQuantity: " << orderquantity << "\nTotal Price: " << total_price << "\n\n";
        order.close();

        cout << "Order placed successfully." << endl;
    }
    else
    {
        cout << "Invalid choice." << endl;
    }
}

void customer::givecomplain()
{
 
 char complaint[100];

  cin.ignore();  // Clear the input buffer
  cout << "Enter your complaint: ";
  cin.getline(complaint,100);

    // writing the complaint to the file
    
  ofstream complain("complain.txt",ios::app);
    if (complain.is_open()) 
    {
        complain << complaint << endl;
        complain.close();

        cout << "Complaint submitted successfully." << endl;
    } else {
       cout << "Error opening complaints file." << endl;
    }
}

void customer::searchitems()
{
        char head[30], item[10][50];
	double Price[10];
	int No_Items[10];
	int i=0;
	
	fstream fs("stock.txt",ios::in);
               fs.getline(head,30,'\n');
		while(fs.getline(item[i],50,' '),fs>>Price[i]>>No_Items[i])
		{
			fs.ignore();
			i++;
		}
	fs.close();
	
	
  char tobefound[50];
   int flag=0;
    // Clear the input buffer
    cout << "Enter the item name to search: ";
     cin.ignore(); 
    cin.getline(tobefound,50);
      for ( int j = 0; j < i; j++)
       {
          if (strcmp(item[j],tobefound) == 0) 
           {          
            flag=1;
            break;
           }
       }
      
      if (flag==1)
      {
       cout<<"ITEM FOUND"<<endl;
      }
      else
      {
       cout<<"ITEM NOT FOUND"<<endl;
      }
}

void customer::schorder()
{
menu.displays();
/////////////////order scheduled food
    char time[20],choiceitem[50];
    int choice, orderquantity, ordercount;
    cout<<"Enter the item you want to order";
    cin.ignore();
    cin.getline(choiceitem,50);
    cout << "Enter the number of item you want to order: ";
    cin >> choice;

if (choice >= 1 && choice <= 10)
    {
        cout << "Enter the quantity: ";
        cin >> orderquantity;
        
        cout<<"Enter the delivery time::";
        cin.ignore();
        cin.getline(time,20);   
        
        int total_price= menu.updatestock(orderquantity,choice);
        
         
        
        // Write order details to the file
        ofstream order("order.txt", ios::app);
        order << "Item: " << choiceitem << "\nQuantity: " << orderquantity << "\nTotal Price: " << total_price <<"\nDelivery time: "<<time<< "\n\n";
        order.close();

        cout << "Order placed successfully." << endl;
    }
    else
    {
        cout << "Invalid choice." << endl;
    }
    
   
}

void customer::viewnoti()
{
   view.viewnoti();////////calls composed class function
}

void customer::game()
{
int choice;

    // asks user to enter a number between 1 and 4
    cout << "Enter a number between 1 and 4 to see a surprise: ";
    cin >> choice;

    // Display surprise shape
    switch (choice) 
    {
        case 1:
            cout << "Surprise! You chose 1! Here's a heart shape:" << endl;
            cout << "  ***   ***" << endl;
            cout << " ***** *****" << endl;
            cout << "*************" << endl;
            cout << " ***********" << endl;
            cout << "  *********" << endl;
            cout << "   *******" << endl;
            cout << "    *****" << endl;
            cout << "     ***" << endl;
            cout << "      *" << endl;
            break;
        case 2:
            cout << "Surprise! You chose 2! Here's a diamond shape:" << endl;
            cout << "    *    " << endl;
            cout << "   ***   " << endl;
            cout << "  *****  " << endl;
            cout << " ******* " << endl;
            cout << "*********" << endl;
            cout << " ******* " << endl;
            cout << "  *****  " << endl;
            cout << "   ***   " << endl;
            cout << "    *    " << endl;
            break;
        case 3:
            cout << "Surprise! You chose 3! Here's a triangle shape:" << endl;
            cout << "    *    " << endl;
            cout << "   ***   " << endl;
            cout << "  *****  " << endl;
            cout << " ******* " << endl;
            cout << "*********" << endl;
            break;
        case 4:
            cout << "Surprise! You chose 4! Here's a square shape:" << endl;
            cout << "*********" << endl;
            cout << "*********" << endl;
            cout << "*********" << endl;
            cout << "*********" << endl;
            cout << "*********" << endl;
            break;
        default:
            cout << "Invalid choice!" << endl;
    }
}

customer::~customer(){}
