#include "stock.h"
#include <iostream>
#include<cstring>
#include <string>
#include<fstream>
#include <iomanip>
using namespace std;
Stock::Stock(){}

Stock::~Stock() {}

void Stock::displays()
{
        char head[30], item[50][50];
	double Price[50];
	int No_Items[50];
	int i=0;
	
	fstream fs("stock.txt",ios::in);
	
	if (!fs)//check if file is not available to read
	{
		cout<<"\nFile not found";
		cout<<"\nCheck file name";
	}
	else//file is available for reading now loading data in arrays appropriately
	{
		cout<<"\nFile Found Congrats";
		fs.getline(head,30,'\n');//reading/loading first line of file
		//reading remianing records of file in arrays appropriately
		while(fs.getline(item[i],50,' '),fs>>Price[i]>>No_Items[i])
		{
			fs.ignore();
			i++;
		}
		
					
	}
	
        itemCount=i;
	fs.close();
	
	
	//now printing data from arrays on screen
	for (int i = 0; i < itemCount - 1; i++) 
	{
          for (int j = 0; j < itemCount - i - 1; j++) 
          {
             if (No_Items[j] > No_Items[j + 1]) 
             {
            // Swap item names
            char tempItem[100]; // assuming a maximum item name length of 100 characters
            strcpy(tempItem, item[j]);
            strcpy(item[j], item[j + 1]);
            strcpy(item[j + 1], tempItem);

            // Swap Prices
            int tempPrice = Price[j];
            Price[j] = Price[j + 1];
            Price[j + 1] = tempPrice;

            // Swap No_Items
            int tempNo_Items = No_Items[j];
            No_Items[j] = No_Items[j + 1];
            No_Items[j + 1] = tempNo_Items;
            }
         }
       }	
       
       
	cout<<"\nData read from file in arrays ::: \n";
	cout<<"\n"<<head<<endl;
	for(int k=0;k<i;k++)
	{      
	        if (No_Items[k] < 10) 
	        {
                  cout << "\x1b[31m"; // Set text color to red
                } 
                else if (No_Items[k] > 20 && No_Items[k] <= 40) 
                {
                   cout << "\x1b[33m"; // Set text color to yellow
                } 
                else if (No_Items[k] > 40) 
                {
                  cout << "\x1b[32m"; // Set text color to green
                }
                
		//cout<<item[k]<<"    |"<<Price[k]<<" |  "<<No_Items[k]<<endl;
		cout << left << setw(15) << item[k] << setw(10) << Price[k] << setw(10) << No_Items[k] << endl;
		cout << "\x1b[0m";
        }

}
void Stock::choices()
{
	char stock;	
	cout<<"\n\nSTOCK HANDLIN\n1.Add stock\n2.Remove stock\n";
	cin>>stock;
	switch (stock)
	{
  		case '1':
 		{
  			addstock();
  			break;
 		}
   		case '2':
   		{
    			removestock();
   		}
   		default:
  		{
    			cout<<"INVALID INPUT"<<endl;
  		}
	}
}

void Stock::addstock()
{
  char newitem[50],newPrice[50],newNo_Items[50];

  cout << "Enter the item name: ";
  cin.ignore();
  cin.getline(newitem,50);

  cout << "Enter the price: ";
  cin.getline(newPrice,50);
  
  cout << "Enter the quantity: ";
  cin.getline(newNo_Items,50);

  ofstream addemp("stock.txt", ios::app);
  addemp<< newitem << " " << newPrice<<" "<<newNo_Items << endl;
  addemp.close();
  cout << "Stock added successfully." << endl;
 
}
void Stock::removestock() {
    int nostock;
    char stockremove[50];
    cout << "Enter the number of stock: ";
    cin >> nostock;
    cout << "Enter the name of the stock to remove: ";
    cin.ignore();
    cin.getline(stockremove, 50);
    int indexToRemove = -1;

    for (int i = 0; i < nostock; ++i) {
        if (strcmp(item[i], stockremove) == 0) {
            indexToRemove = i;
            break;
        }
    }

    if (indexToRemove != -1) {
        // Open the original file for reading
        ifstream stock("stock.txt");
        if (!stock) {
            cout << "Error: Failed to open stock file for reading." << endl;
            return;
        }

        // Open a temporary file for writing
        ofstream tempFile("temp.txt");
        if (!tempFile) {
            cout << "Error: Failed to open temp file for writing." << endl;
            return;
        }

        tempFile << head << endl;
        for (int i = 0; i < nostock; ++i) {
            if (i != indexToRemove) {
                tempFile << item[i] << " " << Price[i] << " " << No_Items[i] << endl;
            }
        }

        // Close file streams
        tempFile.close();
        stock.close();

        // Remove original file and rename temporary file
        remove("stock.txt");
        rename("temp.txt", "stock.txt");

        cout << "Stock removed successfully." << endl;
    } else {
        cout << "Error: Stock not found." << endl;
    }
}

double Stock::updatestock(int orderquantity,int choice)
{
///update stock.txt with new data
        ofstream stock("stock.txt");
        stock << head << endl;
       
        for (int k=0;k<itemCount; k++)
        {
        
        	if (choice==k)
        	{
        		// Update stock
        		No_Items[k] -= orderquantity;
        	}
            stock << item[k] << " " << Price[k] << " " << No_Items[k] << endl;
        }
        // Calculate the price
        double total_price = orderquantity * Price[choice - 1];
        
        stock.close();
        return total_price;
}


