#ifndef ADMIN_H
#define ADMIN_H
#include "stock.h"
#include "notifi.h"
class admin:public Stock,public notifi
{
public:
    admin(); // Constructor declaration
    //////////member functions
    void displaya();
    void logina();
    void choicea();
    void credentials();
    void notification();
    void scorder();
    void viewcomplains();
    ~admin();
};

#endif // ADMIN_H

