#include "notifi.h"
#include <iostream>
#include<cstring>
#include <string>
#include<fstream>
#include <iomanip>
using namespace std;

notifi::notifi(){}

void notifi::viewnoti()
{
ifstream noti("notifications.txt");
    if (noti.is_open()) {
        cout << "Notifications:\n";
        
        char notification[100];
        while (noti.getline(notification, 100)) {
            cout << notification <<endl;
        }
        noti.close();
    } else {
        cout << "Error opening notifications file." << endl;
    }

}

void notifi::addnotifi()
{
    char addnoti[100] = "";
    int n;
    cout<<"*******************************************************************************************************"<<endl;
    cout << "Notification Menu\n1. Add notification\n2. Remove notification" << endl;
    cin >> n;

    switch (n)
    {
        case 1:
        {
            cout << "Enter the Notification:: ";
            cin.ignore(); // Clear the input buffer
            cin.getline(addnoti, 100);

            ofstream file("notifications.txt", ios::app);
            if (!file.is_open())
            {
                cout << "Error: Unable to open file." << endl;
                return;
            }

            file << addnoti << "\n";
            file.close();
            cout << "Notification added successfully." << endl;
            break;
        }
        case 2:
        {
            int index;
            cout << "Enter the index of the notification you want to remove: ";
            cin >> index;

            ifstream inFile("notifications.txt");
            if (!inFile.is_open())
            {
                cout << "Error: Unable to open file." << endl;
                return;
            }

            ofstream outFile("temp.txt");
            if (!outFile.is_open())
            {
                cout << "Error: Unable to create temp file." << endl;
                inFile.close();
                return;
            }

            char notification[100];
            int currentIndex = 0;
            while (inFile.getline(notification, 100))
            {
                if (currentIndex != index)
                {
                    outFile << notification << endl;
                }
                currentIndex++;
            }

            inFile.close();
            outFile.close();

            // Remove the original file and rename the temporary file
            remove("notifications.txt");
            rename("temp.txt", "notifications.txt");

            cout << "Notification removed successfully." << endl;
            break;
        }
        default:
            cout << "Invalid choice." << endl;
            break;
    }
}

notifi::~notifi(){}
